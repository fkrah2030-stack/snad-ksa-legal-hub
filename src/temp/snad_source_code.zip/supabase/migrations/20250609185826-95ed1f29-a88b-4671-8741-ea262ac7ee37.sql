
INSERT INTO public.admins (name, email, role, is_active) 
VALUES ('مدير النظام', 'admin@example.com', 'مدير عام', true);
