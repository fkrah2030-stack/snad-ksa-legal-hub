
SELECT * FROM public.admins WHERE email = 'admin@example.com';
