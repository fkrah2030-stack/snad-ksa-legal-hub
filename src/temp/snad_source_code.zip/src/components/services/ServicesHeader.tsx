
const ServicesHeader = () => {
  return (
    <div className="text-center mb-12">
      <h1 className="text-4xl font-bold text-primary mb-4">خدماتنا القانونية</h1>
      <p className="text-muted-foreground max-w-3xl mx-auto text-lg">
        نقدم مجموعة شاملة من الخدمات القانونية المتخصصة لتلبية جميع احتياجاتك القانونية
      </p>
    </div>
  );
};

export default ServicesHeader;
