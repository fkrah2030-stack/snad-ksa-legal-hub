
const LawyersHeader = () => {
  return (
    <div className="text-center mb-8">
      <h1 className="text-4xl font-bold text-primary mb-4">المحامون المعتمدون</h1>
      <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
        اعثر على أفضل المحامين المتخصصين والمعتمدين في منصة سند
      </p>
    </div>
  );
};

export default LawyersHeader;
